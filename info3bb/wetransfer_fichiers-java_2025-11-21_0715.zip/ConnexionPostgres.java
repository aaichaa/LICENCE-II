import java.sql.*;

public class ConnexionPostgres {

    public static void main(String[] args) {

        // Remplacer selon votre configuration
        String url = "jdbc:postgresql://localhost:5432/selsebil"; //jdbc:postgresql://kafka.iem/sb1245366
        String user = "postgres";  //sb1245366
        String password = "ssss"; // sb1245366

        try {
            // Étape 1 : charger le driver
            Class.forName("org.postgresql.Driver");

            // Étape 2 : établir la connexion
            Connection connexion = DriverManager.getConnection(url, user, password);
            System.out.println("Connexion réussie !");

            // Étape 3a : exécuter une requête simple avec un objet statement

            Statement statement = connexion.createStatement();
            String q1 = "SELECT  nom, id FROM dvd.categorie";
            String q2 = "SELECT nom from dvd.acteur where id =2";
            ResultSet resultSet = statement.executeQuery(q1);

            while (resultSet.next()== true) {
                System.out.println(resultSet.getInt("id")+"|"+ resultSet.getString("nom"));
                
            }
            // Étape 3b : exécuter une requête d'insertion
           
            resultSet = statement.executeQuery("SELECT MAX(id) FROM dvd.pays");
            while (resultSet.next()) {
                System.out.println("Le max des ids des pays =" + resultSet.getString(1));}
            int rowsInsr = statement.executeUpdate("INSERT INTO dvd.pays (id,nom) VALUES (110,'Carthage')");
            System.out.println("Lignes insérées = " + rowsInsr);
             // Étape 3c : exécuter une requête de suppression
            int rowsDel = statement.executeUpdate( "DELETE FROM dvd.pays WHERE nom = 'Carthage'");
            System.out.println("Lignes supprimées = " + rowsDel);
            
            // Étape 4 : exécuter une requête paramétrée  avec un objet preparedStatement
            String query="SELECT id, nom, prenom FROM dvd.acteur WHERE nom = ? ";
            PreparedStatement preparedStatement = connexion.prepareStatement(query);

            // On donne une valeur au paramètre (index 1 = premier ?)
            
             preparedStatement.setString(1, "Nicholson"); 
             
             
               
            // Remplace "Smith" par le nom que tu veux tester

         // Exécuter la requête
             resultSet = preparedStatement.executeQuery();

        // Lire les résultats
        while (resultSet.next()) {
            System.out.println(
            "ID : " + resultSet.getInt("id") +
            ", Nom : " + resultSet.getString("nom") +
            ", Prénom : " + resultSet.getString("prenom")
            );
        }
            // Étape final : fermer proprement
            resultSet.close();
            statement.close();
            preparedStatement.close();
            connexion.close();

        } catch (ClassNotFoundException e) {
            System.out.println("Erreur : Driver PostgreSQL introuvable !");
            e.printStackTrace();

        } catch (SQLException e) {
            System.out.println("Erreur SQL !");
            e.printStackTrace();
        }
    }
}
