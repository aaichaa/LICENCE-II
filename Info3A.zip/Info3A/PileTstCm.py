from PileCm import*
P= Pile()
P.empiler(1)
P.empiler(2)
P.empiler(7)
P.empiler(2)
P.empiler(14)
P.empiler(8)

#print(P._contenu)
#p1 = P.inverser_pile() 
#print(p1._contenu)
#p2 = P.copier_pile()
#print(p2._contenu)
#print(P._contenu)
b = bin_pile(26)
print(b._contenu)

