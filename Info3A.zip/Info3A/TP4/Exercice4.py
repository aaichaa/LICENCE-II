def maximun(L,K):
    