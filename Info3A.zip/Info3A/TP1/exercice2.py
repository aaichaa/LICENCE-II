s = 0
n = 328
#version 1
#while n > 0:
 #   r = n % 10
  #  s = s + r
  ##  n = n // 10
#print("la somme est s =", s)


 #version 2 
c=str(n)
s = 0
for i in range(len(c)):
    s = s + int(c[i])
print(s)


#def converse(n): si besoin de convertir avec une fonction
 #   c=""
  #  c=c+str(n)
  #  return (c) ou # return(str(n)) pâs vraiment besoin de c
#print(converse(12))
    
    
    

    